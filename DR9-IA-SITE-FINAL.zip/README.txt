
DR9 IA — Final Site Package
Files:
- index.html
- style.css
- script.js
- assets/hero.jpg
- assets/favicon.png

Instructions:
1. Unzip and upload folder to GitHub Pages (branch main or gh-pages).
2. Open index.html in a web server for best results (or use GitHub Pages).
3. Customize text, links, or assets as needed.
